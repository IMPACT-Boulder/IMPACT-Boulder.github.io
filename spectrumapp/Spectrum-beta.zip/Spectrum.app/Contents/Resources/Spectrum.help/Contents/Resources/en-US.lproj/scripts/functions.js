$(document).ready(function() {
	$(".nocaret").addClass("toc_hide");
	$(".subcaret").addClass("toc_hide");
});

$(".book").click(function(e) {
	e.preventDefault();
	$(this).parent().find(" > ul").toggleClass("toc_hide");
	$(this).toggleClass("selected");
});

// Add current topic highlight and close TOC if it's been toggled.

$(".mlink").click(function(e) {
	$(".mlink").removeClass("activelink");
	$(this).addClass("activelink");
	window.location.href = "#";
});

// Collapse functionality

$(".collapse_button").click(function(e) {
	e.preventDefault();
	$(".nocaret").addClass("toc_hide");
	$(".subcaret").addClass("toc_hide");
	$(".book").removeClass("selected");
	$(".book + ul").addClass("toc_hide");
});

// Expand functionality

$(".expand_button").click(function(e) {
	e.preventDefault();
	$(".nocaret").removeClass("toc_hide");
	$(".subcaret").removeClass("toc_hide");
	$(".book").addClass("selected");
});


// iframe break-in: if argument is passed in url, parse it and reload topic back into iframe on index.html

$(window).load(function() {
	/*
  var titlestring = new Array([]);
  var query = window.location.search.substring(1);
  var params = query.split("&");
  for (var i = 0; i < params.length; i++) {
    var pos = params[i].indexOf("=");
    if (pos > 0) {
      var key = params[i].substring(0, pos);
      var page = params[i].substring(pos + 1);
      titlestring[key] = page;

      var combine = "pages" + titlestring[key];
      $("#topic").attr("src", combine);
    }
  } */

	var titlestring = new Array([]);
	var query = window.location.search.substring();

	if (query !== "") {
		titlestring = query.split("?");
		var href = titlestring[1].split("=");
		var title = titlestring[2].split("=");
		var titlefinal = decodeURI(title[1]);

		$("#topic").attr("src", "pages" + href[1]);
		document.title = titlefinal;
	}
});

// iOS swiping for off canvas

if (document.addEventListener) {
	document.addEventListener('touchstart', touchBegin, false);
	document.addEventListener('touchmove', touchContinue, false);
}


var Xdir;
var Ydir;

function touchBegin(e) {
	Xdir = e.touches[0].clientX;
	Ydir = e.touches[0].clientY;
}

function touchContinue(e) {
	if (!Xdir || !Ydir) {
		return;
	}

	var Xdiff = Xdir - e.touches[0].clientX;
	var Ydiff = Ydir - e.touches[0].clientY;

	if (Math.abs(Xdiff) > Math.abs(Ydiff)) {
		if (Xdiff > 0) { // Left swipe
			window.location.href = "#navigation";
		} else { // Right swipe
				window.location.href = "#";
		}
	}

	Xdir = null;
	Ydir = null;
}
