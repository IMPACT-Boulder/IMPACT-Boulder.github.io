//
//  SpectrumTemplateTable.swift
//  Spectrum
//
//  Created by Sascha Kempf on 11/15/19.
//  Copyright © 2019 Sascha Kempf. All rights reserved.
//

import Foundation
import SQLite

enum SpectrumTemplateTable {
    static private let name = "SpectrumTemplateTable"
    static private let table = Table(Self.name)

    // MARK: - Properties - SpectrumTemplate Columns
    static fileprivate let uuid = Expression<String>("uuid")
    static fileprivate let createdOn = Expression<String>("createdOn")
    static fileprivate let templateName = Expression<String>("templateName")
    static fileprivate let templateIDLName = Expression<String?>("templateIDLName")
    static fileprivate let templateIdentifier = Expression<String>("templateIdentifier")
    static fileprivate let version = Expression<Double>("version")
    static fileprivate let revision = Expression<Int>("revision")
    static fileprivate let privateAccess = Expression<Bool>("privateAccess")
    static fileprivate let build = Expression<Int>("build")
    static fileprivate let lastSaved = Expression<Date>("lastSaved")
    static fileprivate let lastRevisedBy = Expression<String>("lastRevisedBy")
    static fileprivate let templateTypes = Expression<UUIDArray?>("templateTypes")

    // MARK: - Methods

    /// Drops `SpectrumTemplate` table
    /// - Parameter database: Connection to SQLite data base
    /// - Throws:
    static func drop(in database: Connection) throws {
        try database.run(table.drop(ifExists: true))
    }

    /// Creates `LineTypeLibrary` table
    /// - Parameter database: Connection to SQLite data base
    /// - Throws:
    static func create(in database: Connection) throws {
        try database.run(table.create { t in
            t.column(uuid,  primaryKey:     true)
            t.column(createdOn)
            t.column(templateName)
            t.column(templateIDLName)
            t.column(templateIdentifier)
            t.column(version)
            t.column(revision)
            t.column(privateAccess)
            t.column(build)
            t.column(lastSaved)
            t.column(lastRevisedBy)
            t.column(templateTypes)
        })
    }

    /// Inserts a spectrum template into the table.
    /// - Parameters:
    ///   - spectrumTemplate: A spectrum template
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    static func insert(_ spectrumTemplate: SpectrumTemplate, into database: Connection) throws {

        try database.run(
            table.insert(
                uuid <- spectrumTemplate.uuid.uuidString,
                createdOn <- spectrumTemplate.createdOn,
                templateName <- spectrumTemplate.name,
                templateIDLName <- spectrumTemplate.nameIDL,
                templateIdentifier <- spectrumTemplate.identifier,
                version <- Double(spectrumTemplate.version),
                revision <- spectrumTemplate.revision,
                privateAccess <- spectrumTemplate.privateAccess,
                build <- AppInfo.buildNumber,
                lastSaved <- Date(),
                lastRevisedBy <- spectrumTemplate.lastRevisedBy
            )
        )

        try update(templateTypes: spectrumTemplate.catalogItems,
                   key:           spectrumTemplate.uuid,
                   in:            database)
    }

    /// Updates the columns corresponding to a given `SpectrumTemplate` object in the data base
    /// - Parameters:
    ///   - spectrumTemplate: A spectrum template
    ///   - key: The row's key.
    ///   - database: Connection to SQLite data base.
    /// - Throws: An `SQLite` error.
    /// - Returns: A boolean value indicating whether the row update was successful.
    @discardableResult static func update(_ spectrumTemplate: SpectrumTemplate, key: UUID, in database: Connection) throws -> Bool {
        guard
            let lastRevision = try getRevision(for: key, from: database)
            else { return false }

        try update(templateTypes: spectrumTemplate.catalogItems,
                   key:           key,
                   in:            database)

        let filteredTable = table.filter(uuid == key.uuidString)

        return try database.run(
            filteredTable.update(
                uuid <- spectrumTemplate.uuid.uuidString,
                createdOn <- spectrumTemplate.createdOn,
                templateName <- spectrumTemplate.name,
                templateIDLName <- spectrumTemplate.nameIDL,
                templateIdentifier <- spectrumTemplate.identifier,
                version <- Double(spectrumTemplate.version),
                revision <- lastRevision + 1,
                privateAccess <- spectrumTemplate.privateAccess,
                build <- AppInfo.buildNumber,
                lastSaved <- Date(),
                lastRevisedBy <- spectrumTemplate.lastRevisedBy
            )
        ) == 1
    }

    /// Updates the columns corresponding to a given `SpectrumTemplate` object in the table
    /// - Parameters:
    ///   - spectrumTemplate: A spectrum template
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A boolean value indicating whether the row update was successful
    @discardableResult static func update(_ spectrumTemplate: SpectrumTemplate, in database: Connection) throws -> Bool {
        try update(spectrumTemplate,
                          key: spectrumTemplate.uuid,
                          in:  database)
    }

    /// Updates the line type references of the spectrum template identified by its `key`
    /// - Parameters:
    ///   - templateTypes: A set of `TemplateType`s
    ///   - key: The library's key.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A boolean value indicating the success of the update
    @discardableResult static func update(templateTypes: [TemplateType], key: UUID, in database: Connection) throws -> Bool {
        guard
            let lastRevision = try getRevision(for: key, from: database)
            else { return false }

        for type in templateTypes {
             if try !TemplateTypeTable.exists(type, in: database) {
                 try TemplateTypeTable.insert(type, into: database)
             } else {
                 try TemplateTypeTable.update(templateType: type,
                                              key:          type.uuid,
                                              in:           database)
             }
         }

        let filteredTable = table.filter(uuid == key.uuidString)

        return try database.run(
            filteredTable.update(
                build <- AppInfo.buildNumber,
                lastSaved <- Date(),
                revision <- lastRevision + 1,
                Self.templateTypes <- UUIDArray(templateTypes.map({ $0.uuid }))
            )
        ) == 1
    }

    /// Updates the line type references of the spectrum template identified by its `key`
    ///
    /// - warning: All keys must exist
    /// - Parameters:
    ///   - templateTypes: A set of `TemplateType` keys
    ///   - key: The library's key.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A boolean value indicating the success of the update
    @discardableResult static func update(templateTypes: [UUID], key: UUID, in database: Connection) throws -> Bool {
        guard
            let lastRevision = try getRevision(for: key, from: database)
            else { return false }

        let filteredTable = table.filter(uuid == key.uuidString)

        return try database.run(
            filteredTable.update(
                build <- AppInfo.buildNumber,
                lastSaved <- Date(),
                revision <- lastRevision + 1,
                Self.templateTypes <- UUIDArray(templateTypes))
        ) == 1
    }

    /// Deletes a spectrum template identified by its key.
    /// - Parameters:
    ///   - key: The template's key.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    static func delete(_ key: UUID, in database: Connection) throws {
        try database.run(table.filter(uuid == key.uuidString).delete())
    }

    /// Deletes a spectrum template.
    /// - Parameters:
    ///   - spectrumTemplate: A spectrum template.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    static func delete(_ spectrumTemplate: SpectrumTemplate, in database: Connection) throws {
        try delete(spectrumTemplate.uuid, in: database)
    }

    /// Deletes a set of spectrum templates identified by their keys.
    /// - Parameters:
    ///   - keys: The keys of the templates to delete.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    static func delete(_ keys: [UUID], in database: Connection) throws {
        try keys.forEach { try delete($0, in: database) }
    }

    /// Deletes a set of spectrum templates.
    /// - Parameters:
    ///   - spectrumTemplates: A set of templates.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    static func delete(_ spectrumTemplates: [SpectrumTemplate], in database: Connection) throws {
        try delete(spectrumTemplates.map { $0.uuid }, in: database)
    }

    /// Verifies whether the table already exists.
    /// - Parameter database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A Boolean value indicating whether the `SpectrumTemplate` table already exists.
    static func tableExists(in database: Connection) throws -> Bool {
        guard
            let count = try database.scalar("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='\(Self.name)'") as? Int64
            else { return false }
        return count == 1
    }

    /// Verifies whether the `SpectrumTemplate` table contains a row with the given `uuid` identifier.
    /// - Parameters:
    ///   - key: The row's key.
    ///   - database: Connection to SQLite data base
    /// - Returns: A Boolean value indicating whether the `SpectrumTemplate` table contains a row with the given `uuid`.
    /// - Throws: An `SQLite` error
    static func spectrumTemplateExists(with key: UUID, in database: Connection) throws -> Bool {
        try database.scalar(table.filter(uuid == key.uuidString).select(Self.uuid.count)) == 1
    }

    /// Verifies whether the `SpectrumTemplate` already exists in the table.
    /// - Parameters:
    ///   - spectrumTemplate: A spectrum template
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A boolean value indicating the existence.
    static func exists(_ spectrumTemplate: SpectrumTemplate, in database: Connection) throws -> Bool {
        try spectrumTemplateExists(with: spectrumTemplate.uuid, in: database)
    }

    /// Queries the database for a spectrum template identified by its key.
    /// - Parameters:
    ///   - key: The row's key.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A `SpectrumTemplate` object with the given `uuid` identifier.
    static func query(for key: UUID, from database: Connection) throws -> SpectrumTemplate? {
        guard
            let row = try database.prepare(table.filter( uuid == key.uuidString )).map({$0}).first
            else { return nil }

        let spectrumTemplate = SpectrumTemplate(row: row)

        if let uuids = row[SpectrumTemplateTable.templateTypes]?.uuids {
            spectrumTemplate.catalogItems = try TemplateTypeTable.query(for:  uuids,
                                                                        from: database)
        }

        return spectrumTemplate
    }

    ///  Queries the database for a spectrum template identified by its name.
    /// - Parameters:
    ///   - templateName: The template's name
    ///   - database:  Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A `SpectrumTemplate` object whose `templateName` column matches the given name.
    static func query(forName templateName: String, from database: Connection) throws -> SpectrumTemplate? {
        let thisQuery = table.select(uuid).filter( Self.templateName == templateName )
        guard
            let row = try database.prepare(thisQuery).map({$0}).first,
            let uuid = UUID(uuidString: row[uuid])
            else { return nil }

        return try query(for: uuid, from: database)
    }

    /// Queries the database for a spectrum template identified by its identifier.
    /// - Parameters:
    ///   - templateIdentifier: The template's identifier
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: A `SpectrumTemplate` object whose `templateIdentifier` column matches the given identifier.
    static func query(forIdentifier templateIdentifier: String, from database: Connection) throws -> SpectrumTemplate? {
        let thisQuery = table.select(uuid).filter( Self.templateIdentifier == templateIdentifier )
        guard
            let row = try database.prepare(thisQuery).map({$0}).first,
            let uuid = UUID(uuidString: row[uuid])
            else { return nil }

        return try query(for: uuid, from: database)
    }

    /// <#Description#>
    /// - Parameter database:Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: <#description#>
    static func getSpectrumTemplates(from database: Connection) throws -> [UUID : [UUID]]? {
        var spectrumTemplates = [UUID : [UUID]]()

        let thisQuery = table.select(Self.uuid, Self.templateTypes)
        try database.prepare(thisQuery).forEach({ row in
            if let uuid = UUID(uuidString: row[Self.uuid]) {
                let types = row[Self.templateTypes]?.uuids
                spectrumTemplates[uuid] = types
            }
        })

        return spectrumTemplates
    }

    /// <#Description#>
    /// - Parameters:
    ///   - key: <#key description#>
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns: <#description#>
    static func getRevision(for key: UUID, from database: Connection) throws -> Int? {
        let thisQuery = table.filter( uuid == key.uuidString ).select(revision)
        guard
            let row = try database.prepare(thisQuery).map({$0}).first
            else { return nil }
        return row[revision]
    }

    ///  Returns a dictionary containing the names and keys of all templates stored in the data base.
    /// - Parameter database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    /// - Returns:  A dictionary, whose keys are the template names and values the corresponding `uuid`s.
    static func getSpectrumTemplateNames(from database: Connection) throws -> [String : UUID] {
        var templateNames = [String : UUID]()

        let thisQuery = table.select(Self.uuid, Self.templateName)
        try database.prepare(thisQuery).forEach({ row in
            if let uuid = UUID(uuidString: row[Self.uuid]) {
                let templateName = row[Self.templateName]
                templateNames[templateName] = uuid
            }
        })

        return templateNames
    }

    static func addPrivateAccessColumn(_ database: Connection) throws {
        try database.run(table.addColumn(privateAccess, defaultValue: false))
    }
}

private extension SpectrumTemplate {

    convenience init(row: Row) {
        self.init()
        self.source = .dataBase
        self.uuid = UUID(uuidString: row[SpectrumTemplateTable.uuid])!
        self.name = row[SpectrumTemplateTable.templateName]
        self.nameIDL = row[SpectrumTemplateTable.templateIDLName]
        self.identifier = row[SpectrumTemplateTable.templateIdentifier]
        self.version = Float(row[SpectrumTemplateTable.version])
        self.revision = row[SpectrumTemplateTable.revision]
        self.privateAccess = row[SpectrumTemplateTable.privateAccess]
        self.lastSaved = row[SpectrumTemplateTable.lastSaved]
        self.lastRevisedBy = row[SpectrumTemplateTable.lastRevisedBy]
        self.catalogItems = []
    }
}
