from types import ModuleType
from Foundation import NSObject
from threading import Lock

import sys
import objc
import proxy

PythonBridge = objc.lookUpClass('PythonBridge')
objc.setVerbose(1)

class PythonBridge(objc.Category(PythonBridge)):
    lock = Lock()

    def init(self):
        self = super(PythonBridge, self).init()
        return self

    @objc.typedSelector(b'@@:@@@o^@')
    def makeModuleWithSource_name_importPaths_error_(self, source, name, importPaths, unused):
        try:
            PythonBridge.lock.acquire()
            copy_modules = sys.modules.copy()
            copy_path = sys.path.copy()
            if importPaths is None:
                importPaths = []
            sys.path.extend(importPaths)
            bytecode = compile(source, '<string>', 'exec')
            module = ModuleType(name)
            exec(bytecode, module.__dict__)
            module_proxy = proxy.PythonProxy.alloc().initWithTarget_(module)
            return module_proxy, None
        except:
            return None, proxy.create_error()
        finally:
            PythonBridge.lock.release()
            sys.modules = copy_modules
            sys.path = copy_path

    @objc.typedSelector(b'@@:@@o^@')
    def makeModuleWithName_importPaths_error_(self, name, importPaths, unused):
        try:
            PythonBridge.lock.acquire()
            copy_modules = sys.modules.copy()
            copy_path = sys.path.copy()
            if importPaths is None:
                importPaths = []
            sys.path.extend(importPaths)
            module = __import__(name)
            module_proxy = proxy.PythonProxy.alloc().initWithTarget_(module)
            return module_proxy, None
        except:
            return None, proxy.create_error()
        finally:
            PythonBridge.lock.release()
            sys.modules = copy_modules
            sys.path = copy_path
