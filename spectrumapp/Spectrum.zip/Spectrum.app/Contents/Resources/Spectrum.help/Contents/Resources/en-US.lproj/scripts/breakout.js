$(window).load(function() {
  if (window.location == window.parent.location) {
    var href = document.location.href;
    var docname = href.split('pages').pop();

    window.location.replace("../../index.html?page=" + docname + "?title=" + document.title);
  }
});

function SetPlatform() {
	//alert("Platform: " + navigator.platform + "\nUser Agent: " + navigator.userAgent);

	// Windows: Win32, Win64
	// OSX: MacIntel
	// iOS:

	var platform = navigator.platform;

  switch(platform) {
		case "MacIntel":
			$("head").append('<link rel="StyleSheet" id="platformstyle" href="../../stylesheets/osx.css" type="text/css">');
			break;
    case "iPad":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="../../stylesheets/ios.css" type="text/css">');
      break;
    case "iPhone":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="../../stylesheets/ios.css" type="text/css">');
      break;
    case "Win32":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="../../stylesheets/win32.css" type="text/css">');
      break;
    case "Win64":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="../../stylesheets/win32.css" type="text/css">');
      break;
		default:
			// Do nothing
	}
}

$(document).ready(function() {
	SetPlatform();
});
