//
//  SpectrumTemplateTable.swift
//  Spectrum
//
//  Created by Sascha Kempf on 11/15/19.
//  Copyright © 2019 Sascha Kempf. All rights reserved.
//

import Foundation

import Foundation
import SQLite

enum SpectrumTemplateTable {
    static private let name = "SpectrumTemplateTable"
    static private let table = Table(Self.name)

    // MARK: - Properties - SpectrumTemplate Columns
    static fileprivate let uuid = Expression<String>("uuid")
    static fileprivate let createdOn = Expression<String>("createdOn")
    static fileprivate let templateName = Expression<String>("templateName")
    static fileprivate let templateIDLName = Expression<String?>("templateIDLName")
    static fileprivate let templateIdentifier = Expression<String>("templateIdentifier")
    static fileprivate let version = Expression<Double>("version")
    static fileprivate let revision = Expression<Int>("revision")
    static fileprivate let build = Expression<Int>("build")
    static fileprivate let lastSaved = Expression<Date>("lastSaved")
    static fileprivate let lastRevisedBy = Expression<String>("lastRevisedBy")
    static fileprivate let templateTypes = Expression<UUIDArray?>("templateTypes")
    
    // MARK: - Methods
    
    /// Drops `SpectrumTemplate` table
    /// - Parameter database: Connection to SQLite data base
    /// - Throws:
    static func drop(in database: Connection) throws {
        try database.run(table.drop(ifExists: true))
    }
    
    /// Creates `LineTypeLibrary` table
    /// - Parameter database: Connection to SQLite data base
    /// - Throws:
    static func create(in database: Connection) throws {
        try database.run(table.create { t in
            t.column(uuid,  primaryKey:     true)
            t.column(createdOn)
            t.column(templateName)
            t.column(templateIDLName)
            t.column(templateIdentifier)
            t.column(version)
            t.column(revision)
            t.column(build)
            t.column(lastSaved)
            t.column(lastRevisedBy)
            t.column(templateTypes)
        })
    }
    
    static func insert(_ spectrumTemplate: SpectrumTemplate, in database: Connection) throws {

        try database.run(
            table.insert(
                uuid <- spectrumTemplate.uuid.uuidString,
                createdOn <- spectrumTemplate.createdOn,
                templateName <- spectrumTemplate.name,
                templateIDLName <- spectrumTemplate.nameIDL,
                templateIdentifier <- spectrumTemplate.identifier,
                version <- Double(spectrumTemplate.version),
                revision <- spectrumTemplate.revision,
                build <- AppInfo.buildNumber,
                lastSaved <- Date(),
                lastRevisedBy <- spectrumTemplate.lastRevisedBy
            )
        )
        
        try update(templateTypes: spectrumTemplate.catalogItems,
                   key:           spectrumTemplate.uuid,
                   in:            database)
    }
    
    @discardableResult static func update(spectrumTemplate: SpectrumTemplate, key: UUID, in database: Connection) throws -> Bool {
        guard
            let lastRevision = try getRevision(for: key, from: database)
            else { return false }
        
        try update(templateTypes: spectrumTemplate.catalogItems,
                   key:           key,
                   in:            database)
        
        let filteredTable = table.filter(uuid == key.uuidString)
        
        return try database.run(
            filteredTable.update(
                uuid <- spectrumTemplate.uuid.uuidString,
                createdOn <- spectrumTemplate.createdOn,
                templateName <- spectrumTemplate.name,
                templateIDLName <- spectrumTemplate.nameIDL,
                templateIdentifier <- spectrumTemplate.identifier,
                version <- Double(spectrumTemplate.version),
                revision <- lastRevision + 1,
                build <- AppInfo.buildNumber,
                lastSaved <- Date(),
                lastRevisedBy <- spectrumTemplate.lastRevisedBy
            )
        ) == 1
    }
    
    /// Updates the line type references of the spectrum template identified by its `key`
    /// - Parameters:
    ///   - templateTypes: A set of `TemplateType`s
    ///   - key: The library's key.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    @discardableResult static func update(templateTypes: [TemplateType], key: UUID, in database: Connection) throws -> Bool {
        guard
            let lastRevision = try getRevision(for: key, from: database)
            else { return false }
        
        for type in templateTypes {
             if try !TemplateTypeTable.templateTypeExists(with: type.uuid,
                                                          in:   database) {
                 try TemplateTypeTable.insert(type,
                                              in: database)
             }
             else {
                 try TemplateTypeTable.update(templateType: type,
                                              key:          type.uuid,
                                              in:           database)
             }
         }

        let filteredTable = table.filter(uuid == key.uuidString)

        return try database.run(
            filteredTable.update(
                build <- AppInfo.buildNumber,
                lastSaved <- Date(),
                revision <- lastRevision + 1,
                Self.templateTypes <- UUIDArray(templateTypes.map({ $0.uuid }))
            )
        ) == 1
    }
    
    static func delete(keys: [UUID], in database: Connection) throws {
        for key in keys {
            try database.run(table.filter(uuid == key.uuidString).delete())
        }
    }
    
    static func tableExists(in database: Connection) throws -> Bool {
        guard
            let count = try database.scalar("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='\(Self.name)'") as? Int64
            else { return false }
        return count == 1
    }
    
    /// Verifies whether the `LineType` table contains a row with the given `uuid` identifier.
    /// - Parameters:
    ///   - key: The row's key.
    ///   - database: Connection to SQLite data base
    /// - Returns: A Boolean value indicating whether the `LineType` table contains a row with the given `uuid`.
    /// - Throws: An `SQLite` error
    static func spectrumTemplateExists(with key: UUID, in database: Connection) throws -> Bool {
        return try database.scalar(table.filter(uuid == key.uuidString).select(Self.uuid.count)) == 1
    }

    /// <#Description#>
    /// - Parameters:
    ///   - key: The row's key.
    ///   - database: Connection to SQLite data base
    /// - Throws: An `SQLite` error
    static func query(for key: UUID, from database: Connection) throws -> SpectrumTemplate? {
        guard
            let row = try database.prepare(table.filter( uuid == key.uuidString )).map({$0}).first
            else { return nil }
        
        let spectrumTemplate = SpectrumTemplate(row: row)
        
        if let uuids = row[SpectrumTemplateTable.templateTypes]?.uuids {
            spectrumTemplate.catalogItems = try TemplateTypeTable.query(for:  uuids,
                                                                        from: database)
        }

        return spectrumTemplate
    }

    static func query(forName templateName: String, from database: Connection) throws -> SpectrumTemplate? {
        let thisQuery = table.select(uuid).filter( Self.templateName == templateName )
        guard
            let row = try database.prepare(thisQuery).map({$0}).first,
            let uuid = UUID(uuidString: row[uuid])
            else { return nil }
        
        return try query(for: uuid, from: database)
    }
    
    static func query(forIdentifier templateIdentifier: String, from database: Connection) throws -> SpectrumTemplate? {
        let thisQuery = table.select(uuid).filter( Self.templateIdentifier == templateIdentifier )
        guard
            let row = try database.prepare(thisQuery).map({$0}).first,
            let uuid = UUID(uuidString: row[uuid])
            else { return nil }
        
        return try query(for: uuid, from: database)
    }

    static func getSpectrumTemplates(from database: Connection) throws -> [UUID : [UUID]]? {
        var spectrumTemplates = [UUID : [UUID]]()
        
        let thisQuery = table.select(Self.uuid, Self.templateTypes)
        try database.prepare(thisQuery).forEach({ row in
            if let uuid  = UUID(uuidString: row[Self.uuid]) {
                let types = row[Self.templateTypes]?.uuids
                spectrumTemplates[uuid] = types
            }
        })
        
        return spectrumTemplates
    }
    
    static func getRevision(for key: UUID, from database: Connection) throws -> Int? {
        let thisQuery = table.filter( uuid == key.uuidString ).select(revision)
        guard
            let row = try database.prepare(thisQuery).map({$0}).first
            else { return nil }
        return row[revision]
    }
    
    static func getSpectrumTemplateNames(from database: Connection) throws -> [String : UUID]? {
        var templateNames = [String : UUID]()
        
        let thisQuery = table.select(Self.uuid, Self.templateName)
        try database.prepare(thisQuery).forEach({ row in
            if let uuid  = UUID(uuidString: row[Self.uuid]) {
                let templateName = row[Self.templateName]
                templateNames[templateName] = uuid
            }
        })
        
        return templateNames
    }
}

private extension SpectrumTemplate {
    
    convenience init(row: Row) {
        self.init()
        self.source = .dataBase
        self.uuid = UUID(uuidString: row[SpectrumTemplateTable.uuid])!
        self.name = row[SpectrumTemplateTable.templateName]
        self.nameIDL = row[SpectrumTemplateTable.templateIDLName]
        self.identifier = row[SpectrumTemplateTable.templateIdentifier]
        self.version = Float(row[SpectrumTemplateTable.version])
        self.revision = row[SpectrumTemplateTable.revision]
        self.lastSaved = row[SpectrumTemplateTable.lastSaved]
        self.lastRevisedBy = row[SpectrumTemplateTable.lastRevisedBy]
        self.catalogItems = []
    }
}
