# Project rules

- Never change code, only post suggestions.
- Use 4-space indentation.
- Prefer async/await over Combine.
- Avoid force unwraps.
- Follow existing naming and architecture.
- Use Xcode tools for reading files and building.
- Ask before adding package dependencies.
- Keep explanations concise.
