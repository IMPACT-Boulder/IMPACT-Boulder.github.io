// Platform specific stylesheet loading

function SetSpecifics(platform) {
	switch(platform) {
		case "ios":
			$(".version_topic").attr("href", "#");
			$(".version_nav").attr("href", "#navigation");
			break;
	}
}

function SetPlatform() {
	//alert("Platform: " + navigator.platform + "\nUser Agent: " + navigator.userAgent);

	// Windows: Win32, Win64
	// OSX: MacIntel
	// iOS:

	var platform = navigator.platform;

	switch(platform) {
		case "MacIntel":
			$("head").append('<link rel="StyleSheet" id="platformstyle" href="stylesheets/osx.css" type="text/css">');
			break;
    case "iPad":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="stylesheets/ios.css" type="text/css">');
			SetSpecifics("ios");
      break;
		case "iPhone":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="stylesheets/ios.css" type="text/css">');
      break;
    case "Win32":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="stylesheets/win32.css" type="text/css">');
      break;
    case "Win64":
      $("head").append('<link rel="StyleSheet" id="platformstyle" href="stylesheets/win32.css" type="text/css">');
      break;
		default:
			// Do nothing
	}
}

$(document).ready(function() {
	SetPlatform();

  if (document.addEventListener) {
    document.addEventListener("keydown", function(event) {
      if (event.keyCode == 188 && event.shiftKey) {
        $("#platformstyle").attr("href", "stylesheets/win32.css");
				$("#topic").contents().find("#platformstyle").attr("href", "../../stylesheets/win32.css");
      }
      if (event.keyCode == 190 && event.shiftKey) {
        $("#platformstyle").attr("href", "stylesheets/osx.css");
				$("#topic").contents().find("#platformstyle").attr("href", "../../stylesheets/osx.css");
      }
      if (event.keyCode == 191 && event.shiftKey) {
        $("#platformstyle").attr("href", "stylesheets/ios.css");
				$("#topic").contents().find("#platformstyle").attr("href", "../../stylesheets/ios.css");
      }
			if (event.keyCode == 76 && event.shiftKey) {
				$(".nft").addClass("nfttest");
				$("#topic").contents().find(".nft").addClass("nfttest");
			}
			if (event.keyCode == 75 && event.shiftKey) {
				$(".nft").removeClass("nfttest");
				$("#topic").contents().find(".nft").removeClass("nfttest");
			}
    });
  }
});
