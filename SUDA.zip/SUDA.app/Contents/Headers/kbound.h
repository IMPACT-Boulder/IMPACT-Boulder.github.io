//
//  kbound.h
//  SUDA
//
//  Created by Sascha Kempf on 2/24/18.
//  Copyright © 2018 Sascha Kempf. All rights reserved.
//

#ifndef kbound_h
#define kbound_h

#include <stdio.h>
#include <math.h>

void k90_over_x(void * arg,
                size_t n,
                const double * u,
                double * y);
double kbound90(double start,
                double end,
                double *parameters,
                int *success);

#endif /* kbound_h */
